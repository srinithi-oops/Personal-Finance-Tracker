import type { Metadata } from "next"
import { PlusCircle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MonthlyExpensesChart } from "@/components/monthly-expenses-chart"
import { RecentTransactions } from "@/components/recent-transactions"
import { CategoryBreakdown } from "@/components/category-breakdown"
import { BudgetProgress } from "@/components/budget-progress"
import { TransactionForm } from "@/components/transaction-form"

export const metadata: Metadata = {
  title: "Dashboard",
  description: "Personal Finance Dashboard",
}

export default function DashboardPage() {
  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <TransactionForm>
          <Button className="bg-green-600 hover:bg-green-700">
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Transaction
          </Button>
        </TransactionForm>
      </div>

      {/* Stage 1: Basic Transaction Tracking */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Monthly Expenses</CardTitle>
            <CardDescription>Your spending over the past 6 months</CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            <MonthlyExpensesChart />
          </CardContent>
        </Card>
      </div>

      {/* Stage 2: Categories */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Recent Transactions</CardTitle>
            <CardDescription>Your latest financial activities</CardDescription>
          </CardHeader>
          <CardContent>
            <RecentTransactions />
          </CardContent>
        </Card>
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Spending by Category</CardTitle>
            <CardDescription>How your expenses are distributed</CardDescription>
          </CardHeader>
          <CardContent>
            <CategoryBreakdown />
          </CardContent>
        </Card>
      </div>

      {/* Stage 3: Budgeting */}
      <div className="grid gap-4 md:grid-cols-1">
        <Card>
          <CardHeader>
            <CardTitle>Budget Status</CardTitle>
            <CardDescription>Your current budget progress</CardDescription>
          </CardHeader>
          <CardContent>
            <BudgetProgress />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

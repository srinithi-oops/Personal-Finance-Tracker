"use client"

import { useState } from "react"
import { Pencil, Trash2 } from "lucide-react"
import { format, parse } from "date-fns"

import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useTransactions } from "@/context/transaction-context"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { BudgetFormEdit } from "@/components/budget-form-edit"

export function BudgetList() {
  const { budgets, categories, deleteBudget } = useTransactions()
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [editBudget, setEditBudget] = useState<string | null>(null)

  const handleDelete = (id: string) => {
    setDeleteId(id)
  }

  const confirmDelete = () => {
    if (deleteId) {
      deleteBudget(deleteId)
      setDeleteId(null)
    }
  }

  const handleEdit = (id: string) => {
    setEditBudget(id)
  }

  return (
    <div className="space-y-4">
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Month</TableHead>
              <TableHead>Category</TableHead>
              <TableHead className="text-right">Budget Amount</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {budgets.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="h-24 text-center">
                  No budgets found. Create your first budget to get started.
                </TableCell>
              </TableRow>
            ) : (
              budgets.map((budget) => {
                const category = categories.find((c) => c.id === budget.categoryId)
                const monthDate = parse(budget.month, "yyyy-MM", new Date())
                const formattedMonth = format(monthDate, "MMMM yyyy")

                return (
                  <TableRow key={budget.id}>
                    <TableCell>{formattedMonth}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: category?.color || "#6b7280" }}
                        ></div>
                        {category?.name || "Unknown"}
                      </div>
                    </TableCell>
                    <TableCell className="text-right font-medium">${budget.amount.toFixed(2)}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="icon" onClick={() => handleEdit(budget.id)}>
                          <Pencil className="h-4 w-4" />
                          <span className="sr-only">Edit</span>
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          className="text-red-600"
                          onClick={() => handleDelete(budget.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">Delete</span>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteId !== null} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete this budget.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Edit Budget Dialog */}
      {editBudget && (
        <BudgetFormEdit
          budgetId={editBudget}
          open={editBudget !== null}
          onOpenChange={(open) => !open && setEditBudget(null)}
        />
      )}
    </div>
  )
}

"use client"

import { useMemo } from "react"
import { format } from "date-fns"

import { useTransactions } from "@/context/transaction-context"

export function BudgetProgress() {
  const { transactions, categories, budgets } = useTransactions()

  const currentMonth = format(new Date(), "yyyy-MM")

  const budgetData = useMemo(() => {
    // Get current month's budgets
    const currentBudgets = budgets.filter((budget) => budget.month === currentMonth)

    if (currentBudgets.length === 0) {
      return []
    }

    // Calculate spending for each category
    return currentBudgets
      .map((budget) => {
        const category = categories.find((c) => c.id === budget.categoryId)

        // Get expenses for this category in the current month
        const categoryExpenses = transactions
          .filter((t) => t.type === "expense" && t.categoryId === budget.categoryId && t.date.startsWith(currentMonth))
          .reduce((sum, t) => sum + t.amount, 0)

        const percentage = Math.min(Math.round((categoryExpenses / budget.amount) * 100), 100)

        return {
          categoryId: budget.categoryId,
          categoryName: category?.name || "Unknown",
          budgetAmount: budget.amount,
          spentAmount: categoryExpenses,
          percentage,
          status: percentage > 90 ? "danger" : percentage > 75 ? "warning" : "success",
        }
      })
      .sort((a, b) => b.percentage - a.percentage) // Sort by percentage descending
  }, [transactions, categories, budgets, currentMonth])

  if (budgetData.length === 0) {
    return (
      <div className="text-center p-4">
        <p className="text-muted-foreground">No budgets set for the current month.</p>
        <p className="text-sm text-muted-foreground mt-2">Go to the Budgets page to set up your monthly budgets.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {budgetData.map((item) => (
        <div key={item.categoryId} className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-sm font-medium">{item.categoryName}</div>
            <div className="text-sm text-muted-foreground">
              ${item.spentAmount.toFixed(2)} / ${item.budgetAmount.toFixed(2)}
            </div>
          </div>
          <div className="h-2 w-full rounded-full bg-gray-200 dark:bg-gray-800">
            <div
              className={`h-2 rounded-full ${
                item.status === "danger" ? "bg-red-600" : item.status === "warning" ? "bg-yellow-600" : "bg-green-600"
              }`}
              style={{ width: `${item.percentage}%` }}
            ></div>
          </div>
        </div>
      ))}
    </div>
  )
}

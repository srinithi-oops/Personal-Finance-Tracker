"use client"

import { useMemo } from "react"
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts"

import { useTransactions } from "@/context/transaction-context"

export function CategoryBreakdown() {
  const { transactions, categories } = useTransactions()

  const data = useMemo(() => {
    // Only include expenses
    const expenses = transactions.filter((t) => t.type === "expense")

    // Group expenses by category
    const categoryTotals = expenses.reduce(
      (acc, transaction) => {
        const categoryId = transaction.categoryId
        if (!acc[categoryId]) {
          acc[categoryId] = 0
        }
        acc[categoryId] += transaction.amount
        return acc
      },
      {} as Record<string, number>,
    )

    // Convert to array format for chart
    return Object.entries(categoryTotals)
      .map(([categoryId, value]) => {
        const category = categories.find((c) => c.id === categoryId)
        return {
          name: category?.name || "Unknown",
          value,
          color: category?.color || "#6b7280",
        }
      })
      .sort((a, b) => b.value - a.value) // Sort by value descending
  }, [transactions, categories])

  if (data.length === 0) {
    return <p className="text-center text-muted-foreground">No expense data available.</p>
  }

  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            labelLine={false}
            outerRadius={80}
            fill="#8884d8"
            dataKey="value"
            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip
            formatter={(value: number) => [`$${value.toFixed(2)}`, "Amount"]}
            contentStyle={{ backgroundColor: "white", borderRadius: "8px", border: "1px solid #e2e8f0" }}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  )
}

"use client"

import { useState } from "react"
import { Pencil, Trash2, PlusCircle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useTransactions } from "@/context/transaction-context"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

export function CategoryList() {
  const { categories, transactions, addCategory, updateCategory, deleteCategory } = useTransactions()
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [editCategory, setEditCategory] = useState<{ id: string; name: string; color: string } | null>(null)
  const [newCategory, setNewCategory] = useState<{ name: string; color: string } | null>(null)

  const handleDelete = (id: string) => {
    // Check if category is in use
    const inUse = transactions.some((t) => t.categoryId === id)
    if (inUse) {
      alert("Cannot delete a category that is being used by transactions.")
      return
    }
    setDeleteId(id)
  }

  const confirmDelete = () => {
    if (deleteId) {
      deleteCategory(deleteId)
      setDeleteId(null)
    }
  }

  const handleEdit = (category: { id: string; name: string; color: string }) => {
    setEditCategory(category)
  }

  const handleAdd = () => {
    setNewCategory({ name: "", color: "#10b981" })
  }

  const saveCategory = () => {
    if (editCategory) {
      updateCategory(editCategory)
      setEditCategory(null)
    }
  }

  const createCategory = () => {
    if (newCategory && newCategory.name.trim()) {
      addCategory({
        name: newCategory.name,
        color: newCategory.color,
      })
      setNewCategory(null)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button onClick={handleAdd} className="bg-green-600 hover:bg-green-700">
          <PlusCircle className="mr-2 h-4 w-4" />
          Add Category
        </Button>
      </div>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Color</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {categories.length === 0 ? (
              <TableRow>
                <TableCell colSpan={3} className="h-24 text-center">
                  No categories found.
                </TableCell>
              </TableRow>
            ) : (
              categories.map((category) => (
                <TableRow key={category.id}>
                  <TableCell>
                    <div className="w-6 h-6 rounded-full" style={{ backgroundColor: category.color }}></div>
                  </TableCell>
                  <TableCell>{category.name}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="icon" onClick={() => handleEdit(category)}>
                        <Pencil className="h-4 w-4" />
                        <span className="sr-only">Edit</span>
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        className="text-red-600"
                        onClick={() => handleDelete(category.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                        <span className="sr-only">Delete</span>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteId !== null} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the category.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Edit Category Dialog */}
      <Dialog open={editCategory !== null} onOpenChange={(open) => !open && setEditCategory(null)}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Edit Category</DialogTitle>
            <DialogDescription>Update the category details below.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={editCategory?.name || ""}
                onChange={(e) => setEditCategory((prev) => (prev ? { ...prev, name: e.target.value } : null))}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="color">Color</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="color"
                  type="color"
                  className="w-12 h-10 p-1"
                  value={editCategory?.color || "#000000"}
                  onChange={(e) => setEditCategory((prev) => (prev ? { ...prev, color: e.target.value } : null))}
                />
                <div className="text-sm text-muted-foreground">{editCategory?.color}</div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={saveCategory} className="bg-green-600 hover:bg-green-700">
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Category Dialog */}
      <Dialog open={newCategory !== null} onOpenChange={(open) => !open && setNewCategory(null)}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add Category</DialogTitle>
            <DialogDescription>Enter the details for the new category.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="new-name">Name</Label>
              <Input
                id="new-name"
                value={newCategory?.name || ""}
                onChange={(e) => setNewCategory((prev) => (prev ? { ...prev, name: e.target.value } : null))}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="new-color">Color</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="new-color"
                  type="color"
                  className="w-12 h-10 p-1"
                  value={newCategory?.color || "#10b981"}
                  onChange={(e) => setNewCategory((prev) => (prev ? { ...prev, color: e.target.value } : null))}
                />
                <div className="text-sm text-muted-foreground">{newCategory?.color}</div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={createCategory} className="bg-green-600 hover:bg-green-700">
              Create Category
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

"use client"

import { useMemo } from "react"
import { Bar, BarChart, CartesianGrid, Legend, XAxis, YAxis } from "recharts"
import { format, subMonths, startOfMonth, endOfMonth, parseISO } from "date-fns"

import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { useTransactions } from "@/context/transaction-context"

export function MonthlyExpensesChart() {
  const { transactions } = useTransactions()

  const chartData = useMemo(() => {
    // Get the last 6 months
    const months = Array.from({ length: 6 }, (_, i) => {
      const date = subMonths(new Date(), i)
      return {
        date,
        month: format(date, "MMM"),
        year: format(date, "yyyy"),
        startDate: startOfMonth(date),
        endDate: endOfMonth(date),
      }
    }).reverse()

    // Calculate income and expenses for each month
    return months.map((month) => {
      const monthlyTransactions = transactions.filter((transaction) => {
        const transactionDate = parseISO(transaction.date)
        return transactionDate >= month.startDate && transactionDate <= month.endDate
      })

      const income = monthlyTransactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)

      const expenses = monthlyTransactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)

      return {
        name: `${month.month} ${month.year}`,
        income,
        expenses,
      }
    })
  }, [transactions])

  return (
    <ChartContainer
      config={{
        income: {
          label: "Income",
          color: "hsl(142, 76%, 36%)",
        },
        expenses: {
          label: "Expenses",
          color: "hsl(346, 87%, 43%)",
        },
      }}
      className="h-[300px]"
    >
      <BarChart
        data={chartData}
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <ChartTooltip content={<ChartTooltipContent />} />
        <Legend />
        <Bar dataKey="income" fill="var(--color-income)" />
        <Bar dataKey="expenses" fill="var(--color-expenses)" />
      </BarChart>
    </ChartContainer>
  )
}

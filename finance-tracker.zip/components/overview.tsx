"use client"

import { Bar, BarChart, CartesianGrid, Legend, XAxis, YAxis } from "recharts"

import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  {
    name: "Jan",
    income: 4000,
    expenses: 2400,
  },
  {
    name: "Feb",
    income: 3000,
    expenses: 1398,
  },
  {
    name: "Mar",
    income: 9800,
    expenses: 2000,
  },
  {
    name: "Apr",
    income: 3908,
    expenses: 2780,
  },
  {
    name: "May",
    income: 4800,
    expenses: 1890,
  },
  {
    name: "Jun",
    income: 3800,
    expenses: 2390,
  },
]

export function Overview() {
  return (
    <ChartContainer
      config={{
        income: {
          label: "Income",
          color: "hsl(142, 76%, 36%)",
        },
        expenses: {
          label: "Expenses",
          color: "hsl(346, 87%, 43%)",
        },
      }}
      className="h-[300px]"
    >
      <BarChart
        data={data}
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <ChartTooltip content={<ChartTooltipContent />} />
        <Legend />
        <Bar dataKey="income" fill="var(--color-income)" />
        <Bar dataKey="expenses" fill="var(--color-expenses)" />
      </BarChart>
    </ChartContainer>
  )
}

"use client"

import { ArrowDownIcon, ArrowUpIcon } from "lucide-react"

import { cn } from "@/lib/utils"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { useTransactions } from "@/context/transaction-context"

export function RecentTransactions() {
  const { transactions, categories } = useTransactions()

  // Sort transactions by date (newest first) and take the first 5
  const recentTransactions = [...transactions]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5)

  return (
    <div className="space-y-4">
      {recentTransactions.length === 0 ? (
        <p className="text-center text-muted-foreground">No transactions yet.</p>
      ) : (
        recentTransactions.map((transaction) => {
          const category = categories.find((c) => c.id === transaction.categoryId)
          return (
            <div key={transaction.id} className="flex items-center">
              <Avatar className="h-9 w-9">
                <AvatarFallback
                  className={cn(
                    transaction.type === "expense" ? "bg-red-100" : "bg-green-100",
                    transaction.type === "expense" ? "text-red-700" : "text-green-700",
                  )}
                >
                  {transaction.type === "expense" ? (
                    <ArrowDownIcon className="h-4 w-4" />
                  ) : (
                    <ArrowUpIcon className="h-4 w-4" />
                  )}
                </AvatarFallback>
              </Avatar>
              <div className="ml-4 space-y-1">
                <p className="text-sm font-medium leading-none">{transaction.description}</p>
                <p className="text-sm text-muted-foreground">{category?.name || "Uncategorized"}</p>
              </div>
              <div className="ml-auto font-medium">
                <p className={cn(transaction.type === "expense" ? "text-red-600" : "text-green-600")}>
                  {transaction.type === "expense" ? "-" : "+"}${transaction.amount.toFixed(2)}
                </p>
                <p className="text-xs text-muted-foreground">{transaction.date}</p>
              </div>
            </div>
          )
        })
      )}
    </div>
  )
}

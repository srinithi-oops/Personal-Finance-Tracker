"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { BarChart3, Home, PiggyBank, Wallet, Tag, Calculator } from "lucide-react"

import { cn } from "@/lib/utils"
import { ModeToggle } from "@/components/mode-toggle"

export function SiteHeader() {
  const pathname = usePathname()

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background">
      <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
        <div className="flex gap-6 md:gap-10">
          <Link href="/" className="flex items-center space-x-2">
            <PiggyBank className="h-6 w-6 text-green-600" />
            <span className="inline-block font-bold">FinanceTracker</span>
          </Link>
          <nav className="flex gap-6">
            <Link
              href="/"
              className={cn(
                "flex items-center text-sm font-medium text-muted-foreground",
                pathname === "/" && "text-foreground",
              )}
            >
              <Home className="mr-1 h-4 w-4" />
              Home
            </Link>
            <Link
              href="/dashboard"
              className={cn(
                "flex items-center text-sm font-medium text-muted-foreground",
                pathname === "/dashboard" && "text-foreground",
              )}
            >
              <BarChart3 className="mr-1 h-4 w-4" />
              Dashboard
            </Link>
            <Link
              href="/transactions"
              className={cn(
                "flex items-center text-sm font-medium text-muted-foreground",
                pathname === "/transactions" && "text-foreground",
              )}
            >
              <Wallet className="mr-1 h-4 w-4" />
              Transactions
            </Link>
            <Link
              href="/categories"
              className={cn(
                "flex items-center text-sm font-medium text-muted-foreground",
                pathname === "/categories" && "text-foreground",
              )}
            >
              <Tag className="mr-1 h-4 w-4" />
              Categories
            </Link>
            <Link
              href="/budgets"
              className={cn(
                "flex items-center text-sm font-medium text-muted-foreground",
                pathname === "/budgets" && "text-foreground",
              )}
            >
              <Calculator className="mr-1 h-4 w-4" />
              Budgets
            </Link>
          </nav>
        </div>
        <div className="flex flex-1 items-center justify-end space-x-4">
          <nav className="flex items-center space-x-2">
            <ModeToggle />
          </nav>
        </div>
      </div>
    </header>
  )
}

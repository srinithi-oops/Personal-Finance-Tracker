"use client"

import type React from "react"
import { createContext, useContext, useReducer, useEffect } from "react"

// Define types
export type TransactionType = "expense" | "income"

export interface Category {
  id: string
  name: string
  color: string
}

export interface Transaction {
  id: string
  amount: number
  type: TransactionType
  date: string
  description: string
  categoryId: string
}

export interface Budget {
  id: string
  categoryId: string
  amount: number
  month: string // Format: YYYY-MM
}

interface TransactionState {
  transactions: Transaction[]
  categories: Category[]
  budgets: Budget[]
}

type TransactionAction =
  | { type: "ADD_TRANSACTION"; payload: Transaction }
  | { type: "UPDATE_TRANSACTION"; payload: Transaction }
  | { type: "DELETE_TRANSACTION"; payload: string }
  | { type: "ADD_CATEGORY"; payload: Category }
  | { type: "UPDATE_CATEGORY"; payload: Category }
  | { type: "DELETE_CATEGORY"; payload: string }
  | { type: "ADD_BUDGET"; payload: Budget }
  | { type: "UPDATE_BUDGET"; payload: Budget }
  | { type: "DELETE_BUDGET"; payload: string }
  | { type: "LOAD_DATA"; payload: TransactionState }

const initialCategories: Category[] = [
  { id: "1", name: "Food", color: "#10b981" },
  { id: "2", name: "Housing", color: "#3b82f6" },
  { id: "3", name: "Transportation", color: "#f59e0b" },
  { id: "4", name: "Entertainment", color: "#8b5cf6" },
  { id: "5", name: "Utilities", color: "#ec4899" },
  { id: "6", name: "Healthcare", color: "#06b6d4" },
  { id: "7", name: "Personal", color: "#f43f5e" },
  { id: "8", name: "Education", color: "#14b8a6" },
  { id: "9", name: "Salary", color: "#22c55e" },
  { id: "10", name: "Other", color: "#6b7280" },
]

const initialTransactions: Transaction[] = [
  {
    id: "1",
    amount: 120.5,
    type: "expense",
    date: "2023-06-01",
    description: "Grocery Shopping",
    categoryId: "1",
  },
  {
    id: "2",
    amount: 2400.0,
    type: "income",
    date: "2023-05-28",
    description: "Salary Deposit",
    categoryId: "9",
  },
  {
    id: "3",
    amount: 14.99,
    type: "expense",
    date: "2023-05-25",
    description: "Netflix Subscription",
    categoryId: "4",
  },
  {
    id: "4",
    amount: 55.3,
    type: "expense",
    date: "2023-05-22",
    description: "Gas Station",
    categoryId: "3",
  },
  {
    id: "5",
    amount: 32.75,
    type: "expense",
    date: "2023-05-20",
    description: "Restaurant",
    categoryId: "1",
  },
]

const initialBudgets: Budget[] = [
  { id: "1", categoryId: "1", amount: 500, month: "2023-06" },
  { id: "2", categoryId: "3", amount: 200, month: "2023-06" },
  { id: "3", categoryId: "4", amount: 150, month: "2023-06" },
  { id: "4", categoryId: "5", amount: 200, month: "2023-06" },
]

const initialState: TransactionState = {
  transactions: initialTransactions,
  categories: initialCategories,
  budgets: initialBudgets,
}

const transactionReducer = (state: TransactionState, action: TransactionAction): TransactionState => {
  switch (action.type) {
    case "ADD_TRANSACTION":
      return {
        ...state,
        transactions: [...state.transactions, action.payload],
      }
    case "UPDATE_TRANSACTION":
      return {
        ...state,
        transactions: state.transactions.map((transaction) =>
          transaction.id === action.payload.id ? action.payload : transaction,
        ),
      }
    case "DELETE_TRANSACTION":
      return {
        ...state,
        transactions: state.transactions.filter((transaction) => transaction.id !== action.payload),
      }
    case "ADD_CATEGORY":
      return {
        ...state,
        categories: [...state.categories, action.payload],
      }
    case "UPDATE_CATEGORY":
      return {
        ...state,
        categories: state.categories.map((category) => (category.id === action.payload.id ? action.payload : category)),
      }
    case "DELETE_CATEGORY":
      return {
        ...state,
        categories: state.categories.filter((category) => category.id !== action.payload),
      }
    case "ADD_BUDGET":
      return {
        ...state,
        budgets: [...state.budgets, action.payload],
      }
    case "UPDATE_BUDGET":
      return {
        ...state,
        budgets: state.budgets.map((budget) => (budget.id === action.payload.id ? action.payload : budget)),
      }
    case "DELETE_BUDGET":
      return {
        ...state,
        budgets: state.budgets.filter((budget) => budget.id !== action.payload),
      }
    case "LOAD_DATA":
      return action.payload
    default:
      return state
  }
}

// Create context
interface TransactionContextType extends TransactionState {
  addTransaction: (transaction: Omit<Transaction, "id">) => void
  updateTransaction: (transaction: Transaction) => void
  deleteTransaction: (id: string) => void
  addCategory: (category: Omit<Category, "id">) => void
  updateCategory: (category: Category) => void
  deleteCategory: (id: string) => void
  addBudget: (budget: Omit<Budget, "id">) => void
  updateBudget: (budget: Budget) => void
  deleteBudget: (id: string) => void
  getCategoryById: (id: string) => Category | undefined
}

const TransactionContext = createContext<TransactionContextType | undefined>(undefined)

// Create provider
export const TransactionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(transactionReducer, initialState)

  // Load data from localStorage on initial render
  useEffect(() => {
    const savedData = localStorage.getItem("financeTrackerData")
    if (savedData) {
      try {
        const parsedData = JSON.parse(savedData)
        dispatch({ type: "LOAD_DATA", payload: parsedData })
      } catch (error) {
        console.error("Failed to parse saved data:", error)
      }
    }
  }, [])

  // Save data to localStorage whenever state changes
  useEffect(() => {
    localStorage.setItem("financeTrackerData", JSON.stringify(state))
  }, [state])

  const addTransaction = (transaction: Omit<Transaction, "id">) => {
    const newTransaction = {
      ...transaction,
      id: Date.now().toString(),
    }
    dispatch({ type: "ADD_TRANSACTION", payload: newTransaction })
  }

  const updateTransaction = (transaction: Transaction) => {
    dispatch({ type: "UPDATE_TRANSACTION", payload: transaction })
  }

  const deleteTransaction = (id: string) => {
    dispatch({ type: "DELETE_TRANSACTION", payload: id })
  }

  const addCategory = (category: Omit<Category, "id">) => {
    const newCategory = {
      ...category,
      id: Date.now().toString(),
    }
    dispatch({ type: "ADD_CATEGORY", payload: newCategory })
  }

  const updateCategory = (category: Category) => {
    dispatch({ type: "UPDATE_CATEGORY", payload: category })
  }

  const deleteCategory = (id: string) => {
    dispatch({ type: "DELETE_CATEGORY", payload: id })
  }

  const addBudget = (budget: Omit<Budget, "id">) => {
    const newBudget = {
      ...budget,
      id: Date.now().toString(),
    }
    dispatch({ type: "ADD_BUDGET", payload: newBudget })
  }

  const updateBudget = (budget: Budget) => {
    dispatch({ type: "UPDATE_BUDGET", payload: budget })
  }

  const deleteBudget = (id: string) => {
    dispatch({ type: "DELETE_BUDGET", payload: id })
  }

  const getCategoryById = (id: string) => {
    return state.categories.find((category) => category.id === id)
  }

  return (
    <TransactionContext.Provider
      value={{
        ...state,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        addCategory,
        updateCategory,
        deleteCategory,
        addBudget,
        updateBudget,
        deleteBudget,
        getCategoryById,
      }}
    >
      {children}
    </TransactionContext.Provider>
  )
}

// Create hook for using the context
export const useTransactions = () => {
  const context = useContext(TransactionContext)
  if (context === undefined) {
    throw new Error("useTransactions must be used within a TransactionProvider")
  }
  return context
}
